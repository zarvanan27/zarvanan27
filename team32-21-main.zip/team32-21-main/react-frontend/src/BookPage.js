//import './bookpage.css';
/*import React, { Component } from 'react';
//import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import styled from 'styled-components';

export default class BookPage extends Component {

  // Called when component is first created
  constructor(props) {
    super(props);

    this.state = {
      title: "Loading...",
      description: "Loading...",
      image: "Loading",
    }
  }

  // Called when component is loaded
  componentDidMount() {
    fetch('/api/books/' + this.props.id).then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        title: json.title,
        description: json.description,
        image: json.image,
      })
    });
  }

  // The function code from pre-class BookPage
  render() {
    var props = this.props;

    const Bookcover = () => (
      <img className="bookcover" src={this.state.image} alt={this.state.title} />
    );

    const Booktitle = () => (
      <h1 className="booktitle">
        {this.state.title}
      </h1>
    );

    const Bookdescr = () => (
      <p className="bookdescr">
        {this.state.description}
      </p>
    );

    // Button to request the desired book from the owner
    const Reservebutton = () => (
      <section>
        <button onClick={PostRequest}>Request From Mark</button>
      </section>
    )
    
    function RequestSuccessful(){
      document.getElementById("request-confirmation").innerHTML = "Book requested";
    }

    // Posts the desired information to be received by the backend (more secure)
    function PostRequest(){
      RequestSuccessful()
      fetch('/api/reservations', {
        method: 'POST',
        body: JSON.stringify({"book_id":props.id}),
      })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
      })
    }

    return (
      <>
        <Format>
          <section className="book-page-info" style={{ flex: 1, alignItems: 'center', justifyContent: 'center', alignSelf: 'stretch' }}>
            <div style={{ display: "flex", flexDirection: "row" }}>
              <div className="bookcoversect">
                <section className="bookcover-border">
                  <Bookcover />
                </section>
              </div>

              <article className="book-data" style={{ display: "flex", flexDirection: "column" }}>
                <bookinfosect>
                  <section className="bookdata-border">
                    <Booktitle />
                    <Bookdescr />
                  </section>
                </bookinfosect>

                <div className="requestbtn">
                  <section className="borrowbtnsection">
                    <Reservebutton />
                    <p id="request-confirmation" className="req-con"></p>
                  </section>
                </div>
              </article>
            </div>
          </section>
        </Format>
      </>
    )
  }
}

// Styles different sections of the page
const Format = styled.div`
  .bookcoversect { 
    float: left;
    height: 629px;
    width: 450px;
    background: #d1d1d1;
    padding: 20px;
  }

  bookinfosect {
    float: left;
    height: 90%;
    width: 100%;
    background: #d1d1d1;
    padding: 20px;
  }

  requestbtn {
    width: 100%;
    float: left;
    background: #d1d1d1;
  }

`;

//<a href="/" className="borrowbtn" color="black">Request From Mark</a>*/
