//import "./App.css";
import styled from "styled-components";
import { AccountBox } from "./components/accountBox";
import { ReactComponent as Logo } from './Logo_black.svg';
import { useState } from 'react';
import { BrowserRouter as Router, Route, Routes} from "react-router-dom";
import React from 'react';
import Main from './components/pages/Main';
//import BookPage from './components/pages/BookPage';


const AppContainer = styled.div`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: rgb (160 ,160 ,2);
`;



function App() {
  const [isLoggedIn, logIn] = useState(false);
  const [token, setToken] = useState(-1);
  const [userID, setUserID] = useState(-1);
  return (
    <Router>
      <Routes>
        <Route path="*" element={<Main isLoggedIn={isLoggedIn} token={token} userid={userID}/>}/>
        <Route path="/sign-in" element={
        <AppContainer>
          <div>
            <Logo />
          </div>
          <AccountBox logIn={logIn} setToken={setToken} setUserID={setUserID}/>
        </AppContainer>}/>
      </Routes>
    </Router>
  )
}

export default App;
