<div className="heading" style={{display:"flex",flexDirection:"row"}}>
        <title>Library of Peers</title>
        <Logo />
        <Touchbar />
      </div>


const Logo = () => (
  <>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>
    <section className='logo' style={{display:"flex",flex:"1",flexDirection:"row"}}>
      <img 
      className="lop" src={logo} alt="Library of Peers"
      />
    </section>
  </>
);

const Touchbar = () => (
  <>
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"></meta>
    <section className='touchbar' style={{display:"flex",flex:"1",flexDirection:"row",alignContent:"right"}}>
      <img 
      className="calendar" alt="Calendar" align="right"
      />
      <img 
      className="notifs" alt="Notifications" align="right"
      />
      <img 
      className="borrowed" alt="Borrowed Books" align="right"
      />
      <img 
      className="preferences" src={pref} alt="Your Preferences" align="right" width="40" height="40"
      />
      <img 
      className="profile" src={profile} alt="Profile" usemap="#profilemap" align="right" width="40" height="40"
      />
      <map name="profilemap">
        <area shape="circle" />
      </map>
    </section>
  </>  
);