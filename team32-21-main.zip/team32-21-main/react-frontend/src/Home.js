import './bookpage.css';
import './global.css';
import React, { Component } from 'react';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router, Routes, Route, useParams, Link } from "react-router-dom";
import { NavigationBar } from "./components/NavigationBar";
import BookPage from "./BookPage.js"
import { Card, Button } from 'react-bootstrap';
//import { Dimensions, Platform, PixelRatio } from 'react-native';

export default class Home extends Component {
    render() {
        return (
            <>
                <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"></meta>
                <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"></link>

                <Router>
                    <NavigationBar />
                    <div className='content-section'>
                    <Routes>
                        <Route path="/" element={<HomePage/>}/>
                        <Route path="/book/:id" element={<RoutedBookPage/>}/>
                    </Routes>
                    </div>
                </Router>
            </>
        )
    }
}

function RoutedBookPage() {
    let { id } = useParams();
    return (
        <BookPage id={id}/>
    );
}

class HomePage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cards: []
        };
    }

    componentDidMount() {
        fetch('/api/books').then(response => {
          return response.json();
        }).then(json => {
          this.setState({
            cards: json.books
          })
        });
      }
    
    render() {
        var rows = this.state.cards.map((card) => <BookCard details={card}/>);
        return (
            <div>
                <h1>Recommended For You:</h1>
            <div className='card-container'>{rows}</div>
            </div>
        )
    }
}

class BookCard extends Component {
    render() {
        return (
            <Card style={{ width: '18rem' }}>
                <Card.Img variant="top" src={this.props.details.image} />
                <Card.Body>
                    <Card.Title>{this.props.details.title}</Card.Title>
                    <Card.Text>
                        {this.props.details.description}
                    </Card.Text>
                    <Button variant="primary" as={Link} to={"/book/"+ this.props.details.id}>View Details</Button>
                </Card.Body>
            </Card>
        )
    }
}