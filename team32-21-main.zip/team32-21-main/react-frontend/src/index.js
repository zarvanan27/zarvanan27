/*import "./App.css";
import './bookpage.css';
import React from 'react';
import ReactDOM from 'react-dom';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import App from './App.js'*/
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

//ReactDOM.render(<BookPage title={title} description={description} image={image}/>, document.getElementById('root'));
//ReactDOM.render(<App />, document.getElementById('root'));