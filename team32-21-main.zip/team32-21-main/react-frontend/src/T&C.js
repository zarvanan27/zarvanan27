import {useHistory} from "react-router-dom";


function T&C() {

    let history=useHistory(); 
    return (
       <div>
        Library of Peers GDPR Privacy Policy 

Introduction 

1.1 Library of Peers (“Company” or “We”) respect our users’ privacy and strive to protect it through our compliance with this policy. This policy describes: 

What personal data we collect 

How personal data is collected 

How personal data is stored 

How we use personal data 

How personal data is shared and with whom 

How long personal data is kept 

Your rights regarding personal data 

How to contact us 

 

What personal data we collect 

2.1 Library of Peers collects the following data: 

First Name 

Last Name 

Postal address 

Email address 

Telephone number 

Profile picture 

Password 

 

2.2 Library of Peers is not intended for anyone under the age of 18, and we do not 	knowingly collect personal data from anyone under the age of 18. Should we learn that 	we have collected or received data from anyone under the age of 18, we will delete it. 

 

How personal data is collected 

You directly provide Library of Peers with all the data we collect. We collect and process data when you: 

Register for an account  

Fill in forms online  

 

How personal data is stored 

We recognise the importance of privacy and are committed to protecting our 		customers’ personal data. You should, however, be aware that no system is ever 		completely secure. We encrypt customer data and have a policy to ensure that personal 	data is not stored for longer than necessary (see section 7). 

 

How we use personal data 

We use personal data that you provide, or that we collect from you for the following 	purposes: 

To set up and operate your Library of Peers account 

To alert you of updates to the app, and any changes to the services we provide through it 

 

How personal data is shared and with whom 

6.1 We do not share your personal data with anyone unless we are required to do so by 	law, or 	it is essential for the running of the app. 

6.2 We do not sell your information to anyone. 

6.3 Your first name and profile picture will be displayed publicly on the app, where other 	 users will be able to view them. These are shared at your own risk. Library of Peers 	cannot control the actions of the other app users, therefore cannot guarantee that your 	publicly displayed information will not be viewed by unauthorised persons. 

6.4 Your approximate location will be shared with other users so that they can view who 	has books in their local area. Only you will be able to see the exact location you have 	saved on the app, unless you choose to share it with another user so that they can 	collect a book directly from there. If you choose to lend a book elsewhere (i.e. in a 	public space, instead of your home address), your address will not be shared with the 	book borrower. 

 
How long personal data is kept 

Library of Peers will only store your personal data for as long as it is necessary: 		specifically, while you have an account with us. If you choose to delete your account, we 	will delete your personal data as soon as possible, and always within 30 days of account 	deletion. 

 

Your rights regarding personal data 

Library of Peers would like users to be fully aware of their data protection rights. Every 	user is entitled to the following: 

The right to access – You have the right to be informed of the personal data we process about you and request access to it. 

The right to rectification – You have the right to request that we correct any information that you believe to be incorrect. 

The right to erasure – You have the right to request that we delete your personal information. In order to delete your personal information, we must also delete your account. 

The right to restrict processing – You have the right to request that we temporarily or permanently stop processing your data. You should be aware that this may restrict the functionality of the app. 

The right to object processing – You have the right to object to us processing your personal data. You should be aware that this may restrict the functionality of the app. 

The right to data portability – You have the right to request a digital copy of your personal data. 

 

How to contact us  

If you have any questions regarding Library of Peers’s privacy policy, your stored 		personal data, or you would like to exercise your data protection rights, please do not 	hesitate to contact us. You can reach us via the following: 

Email: libraryofpeers32@gmail.com " 
       </div>

    );
}

export default T&C;