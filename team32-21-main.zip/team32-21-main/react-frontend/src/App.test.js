import { render, screen } from '@testing-library/react';
//import BookPage from './BookPage';
//import App from './App'
import { AccountBox } from './components/accountBox';
import { BrowserRouter as Router} from "react-router-dom";
//import sum from './sum';

/*test('sums numbers', () => {
  expect(sum(1, 2)).toEqual(3);
  expect(sum(2, 2)).toEqual(4);
});*/

/*test('renders book page', () => {
  render(<BookPage />);
  const linkElement = screen.getByText(/Request From Mark/i);
  expect(linkElement).toBeInTheDocument();
});*/

test('renders welcome page', () => {
  render(<Router><AccountBox /></Router>);
  const linkElement = screen.getByText(/Welcome/i);
  expect(linkElement).toBeInTheDocument();
});
