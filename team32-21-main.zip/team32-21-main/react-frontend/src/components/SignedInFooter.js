import React from 'react'
import { Link } from 'react-router-dom';
import './SignedInFooter.css';

function SignedInFooter() {
  return (
    <div className="footer-container">
      <section className="footer-sign-up">
        <p id="footer-sign-up-heading" className="footer-sign-up-heading">
          Library of Peers
        </p>
      </section>
      <div className="footer-links">
        <div className="footer-link-wrapper-si">
          <div className="footer-link-items">
            <Link to="/"> <p id="link-text" className="link-text"> About Us </p> </Link>
            <Link to="sign-in"> <p id="link-text" className="link-text"> How it works </p> </Link>
            <Link to='/'> <p id="link-text" className="link-text"> Contact Us </p> </Link>
            <Link to='/'> <p id="link-text" className="link-text"> Support </p> </Link>
            <Link to="/"> <p id="link-text" className="link-text"> Terms of Service </p> </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignedInFooter