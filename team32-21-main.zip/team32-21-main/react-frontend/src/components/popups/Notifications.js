import './Notifications.css';
import React, { Component } from 'react';
 
function NotificationsItem(props) {
  return(
    <span id="notification-items" tabIndex="0" onClick={() => PostRequest(props)}>{props.name} requested {props.title}</span>
  )
}

function PostRequest(props){
  console.log(props);
  fetch('/api/borrowed', {
    method: 'POST',
    body: JSON.stringify({"book_id":props.bookid, "token":props.token, "user_id":props.userid}),
  })
  .then(response => {
    if(response.status === 500) {
      alert("This book has already been lent out!");
    }
    return response.json();
  }).then(data => {
    console.log('Success:', data);
  })
}

class Notifications extends Component {

  constructor(props) {
    super(props);
    this.state = { notifications: [] };
    this.listRef = React.createRef();
  }

  componentDidMount() {
    var address = '/api/reservations?token='+this.props.token+"&owner_id="+this.props.userid;
    fetch(address)
    .then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        notifications: json.reservations
      });
    });
  }

  render(){
    var notificationsData = this.state.notifications.map((notifications) => <NotificationsItem name={notifications.name} title={notifications.title} userid={notifications.user_id} bookid={notifications.book_id} token={this.props.token}/>);
    return (
      <>
        {notificationsData}
      </>
    )
  }
}

export default Notifications;