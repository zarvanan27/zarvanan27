import './Calendar.css';
import React, { Component } from 'react';

function CalendarItem(props) {
  return(
    <p href="/" tabIndex="0" id="calendar-items">{props.title} due by {props.date}</p>
  )
}

function LentItem(props) {
  return(
    <p href="/" id="calendar-items" onClick={() => DeleteRequest(props)}>{props.title} to be returned to you by {props.date}</p>
  )
}


function DeleteRequest(props){
  fetch('/api/borrowed?book_id='+props.bookid+'&token='+props.token, {
    method: 'DELETE'
  })
  .then(response => response.json())
  .then(data => {
    console.log('Success:', data);
  })
}


class Calendar extends Component {

  constructor(props) {
    super(props);
    this.state = { calendar: [] , lent: []};
    this.listRef = React.createRef();
  }

  componentDidMount() {
    var address = '/api/borrowed?token='+this.props.token+"&user_id="+this.props.userid;
    fetch(address)
    .then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        calendar: json.borrowed
      });
    });
    var address2 = '/api/borrowed?token='+this.props.token+"&owner_id="+this.props.userid;
    fetch(address2)
    .then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        lent: json.borrowed
      });
    });
  }
  
  render(){
    var calendarData = this.state.calendar.map((calendar) => <CalendarItem title = {calendar.title} date={calendar.due}/>);
    var lentData = this.state.lent.map((lent) => <LentItem title = {lent.title} date={lent.due} token={this.props.token} bookid={lent.book_id}/>);
    return (
      <>
        {calendarData}
        {lentData}
      </>
    )
  }
}

export default Calendar;