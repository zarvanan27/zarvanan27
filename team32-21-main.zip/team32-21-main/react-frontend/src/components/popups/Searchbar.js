import './Searchbar.css';
import '../SignedInNavbar.css';
import { Form } from 'react-bootstrap';
import React from 'react';
 
const Searchbar = () => (
  <div class="dropdown-content-searchbar">
    <Form className="search-bar-form">
      <input className="search-bar" type="text" placeholder="Search for Books..." />
    </Form>
  </div>
);

export default Searchbar;