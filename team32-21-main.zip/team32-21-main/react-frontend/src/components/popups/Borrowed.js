import './Borrowed.css';
import React, { Component } from 'react';
 
function BorrowedItem(props) {
  return(
    <p href="/" id="borrowed-items">{props.title}</p>
  )
}

class Borrowed extends Component {

  constructor(props) {
    super(props);
    this.state = { borrowed: [] };
    this.listRef = React.createRef();
  }

  componentDidMount() {
    var address = '/api/borrowed?token='+this.props.token+"&user_id="+this.props.userid;
    fetch(address)
    .then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        borrowed: json.borrowed
      });
    });
  }  

  render(){
    var borrowedData = this.state.borrowed.map((borrowed) => <BorrowedItem title = {borrowed.title}/>);
    return (
      <>
        {borrowedData}
      </>
    )
  }
}

export default Borrowed;