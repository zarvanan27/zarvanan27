/*import React, { Component } from 'react';
import Select from 'react-select';
import SignedInNavbar from '../SignedInNavbar';
import SignedOutNavbar from '../SignedOutNavbar';
import Footer from '../Footer';
import './Preferences.css';
import styled from "styled-components";

const Container = styled.div``;

const options = [
  { value: "<1 mile", label: "<1 mile" },
  { value: "<5 mile", label: "<5 mile" },
  { value: "<10 mile", label: "<10 mile" },
  { value: "<20 mile", label: "<20 mile" },
  { value: "all", label: "all" }
]


class Preferences extends Component {

  state = { selectedOption: null };

  handleChange = selectedOption => {
    this.setState({ selectedOption });
    console.log(`Option selected:`, selectedOption);
  };
  render(){

    const { selectedOption } = this.state;

    return (
      <Container>
        <SignedOutNavbar />
          <Select 
            value={selectedOption}
            onChange={this.handleChange}
            options={options}
          />
        <Footer />
      </Container>
    );
  }
}

export default Preferences;*/


import './Preferences.css';
import React, { Component } from 'react';
import FontSizeChanger from 'react-font-size-changer';

class Preferences extends Component {
  render(){
    return (
      <>
        <FontSizeChanger
          targets={['#nav-links', '#category-headers', '#book-text', '#footer-sign-up-heading', 
          '#link-text', '#bookpage-title', '#bookpage-desc', '#request-links', '#calendar-items',
          '#notification-items', '#borrowed-items', '#btn-nav--outline', '#adding-ISBN', '#book-upload-heading',
          '#uploading-book', '#btn--outline', '#footer-sign-up-heading', '#link-text', '#btn-nav--outline active',
          '#btn-nav--outline', '#input-headings']}  
          customButtons={{
            up: <button><p style={{cursor: 'pointer'}}>/\</p></button>,
            down: <button><p style={{cursor: 'pointer'}}>\/</p></button>,
            style: {
              backgroundColor: '#a9a7a0',
              color: 'white',
              WebkitBoxSizing: 'border-box',
              WebkitBorderRadius: '5px',
              width: '40px',
              cursor: 'pointer',
              paddingRight: '0px'
            },
            buttonsMargin: 10
          }}
        />
      </>
    )
  }
}

export default Preferences;