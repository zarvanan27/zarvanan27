import React from 'react'
import { Button } from './Button';
import { Link } from 'react-router-dom';
import './SignedOutFooter.css';

function SignedOutFooter() {
  return (
    <div className="footer-container">
      <section className="footer-sign-up">
        <p className="footer-sign-up-heading" id="footer-sign-up-heading">
          Library of Peers
        </p>
        <div className="input-areas">
          <form>
            <Link tabIndex="1" to='/sign-in'>
              <Button buttonStyle="btn--outline">Register</Button>
            </Link>
          </form>
        </div>
      </section>
      <div className="footer-links">
        <div className="footer-link-wrapper">
          <div className="footer-link-items">
            <Link to="/"> <p className="link-text" id="link-text"> About Us </p> </Link>
            <Link to="/"> <p className="link-text" id="link-text"> How it works </p> </Link>
            <Link to='/'> <p className="link-text" id="link-text"> Contact Us </p> </Link>
            <Link to='/'> <p className="link-text" id="link-text"> Support </p> </Link>
            <Link to="/"> <p className="link-text" id="link-text"> Terms of Service </p> </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignedOutFooter