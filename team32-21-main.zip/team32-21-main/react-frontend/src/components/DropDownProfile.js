import React, {useState} from 'react';
import './DropDown.css';
import { Link } from 'react-router-dom';


function DropDownProfile(props) {

  function DropDownItem(subprops) {
    return(
      <div>
        <p id="request-links" tabIndex={0} onClick={handleClick} >{subprops.name}
          <Link to={"/lender/" + subprops.id} style={{ textDecoration: "none" }}> </Link>
        </p>
      </div>
    )
  }

  const [click, setClick] = useState(false);

  const handleClick = () => setClick(!click);



  var dropdowns = props.lender.map((lender) => <DropDownItem name = {lender.name} />);
  
  return (
  <div className="dropdown-request">
    <button id="request-links" className='request-links' onClick={handleClick}>
      View Lender Profiles
    </button>
    <div className={click ? "dropdown-content-appear" : "dropdown-content"}>
      {dropdowns}
    </div>
  </div>
  );
}
 
export default DropDownProfile

