import React, { useState } from 'react';
import './Navbar.css';

function Navbar() {
  return (
    <Navigationbar>
      <NavItem title="Calendar" />
      <NavItem title="Notifications" />
      <NavItem title="Borrowed" />
    </Navigationbar>
  );
}

function DropdownMenu() {

  function DropdownItem(props) {
    return (
      <a href="#" className="menu-item">
        <span className="icon-button">{props.leftIcon}</span>
        {props.children}
      
      <span className="icon-right">{props.rightIcon}</span>
      </a>
    )
  }
  
  return (
    <div className="dropdown">
      <DropdownItem>Calendar</DropdownItem>
      <DropdownItem 
        leftIcon={"left"}
        rightIcon={"right"}/>
    </div>
  );
}

function Navigationbar(props) {
  return (
    <nav className="navigationbar">
      <ul className="navbar-nav">

      </ul>
    </nav>
  )
}

function NavItem(props) {

  const [open, setOpen] = useState(false);

  return (
    <li className="navbar-item">
      <a href="#" className="icon-button" onClick={() => setOpen(!open)}>
        {props.title}
      </a>
      {open && props.children}
    </li>
  );
}

export default Navbar;