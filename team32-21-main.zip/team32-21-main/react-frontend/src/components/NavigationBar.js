import React from 'react';
import logo from "../lop-logo-new.png";
import { Nav, Navbar, Form, FormControl } from 'react-bootstrap';
import styled from 'styled-components';
import { Link } from 'react-router-dom'

const Styles = styled.div`
  .navbar { background-color: #e9e7e0; }
  
  a, .navbar-nav, .navbar-light .nav-link {
    color: #000000;
    background-color:#e9e7e0;
    &:hover { color: white; }
  }

  .search-bar {
    position: absolute;
    left: 200px;
    width: 230px
  }

  .task-bar {
    position: absolute;
    right: 40px;
  }

`;

export const NavigationBar = () => (
  <Styles>
    <Navbar expand="lg">
      <Navbar.Brand as={Link} to="/"> 
        <img className="lop" src={logo} alt="Library of Peers"/>
      </Navbar.Brand>
      <Form className="search-bar">
        <FormControl type="text" placeholder="Search for Books..." />
      </Form>
      <Navbar.Toggle aria-controls="basic-navbar-nav" background="#6b6a68"/>
      <Navbar.Collapse id="basic-navbar-nav" background="#6b6a68">
        <Nav className="task-bar" background="#e9e7e0">
          <Nav.Item><Nav.Link as={Link} to="/">Calendar</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link as={Link} to="/">Notifications</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link as={Link} to="/">Borrowed</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link as={Link} to="/">Preferences</Nav.Link></Nav.Item>
          <Nav.Item><Nav.Link as={Link} to="/">Profile</Nav.Link></Nav.Item>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  </Styles>
)