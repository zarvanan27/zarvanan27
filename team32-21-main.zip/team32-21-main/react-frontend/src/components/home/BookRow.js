import React, { Component } from 'react';
import '../../App.css';
import './BookRow.css';
import { ScrollView, Dimensions } from 'react-native';
import BookTemplates from "../home/BookTemplates";

const window = Dimensions.get("window");
const windowWidth = window.width;
var bookQuant = 18;

class BookRow extends Component {

  constructor(props) {
    super(props);
    this.state = { sliderNumber: 0, disable: false, isMoved: false, fewBooks: true, cards: [] };
    this.listRef = React.createRef();
    this.handleClick = this.handleClick.bind(this)
  }

  componentDidMount() {
    var address = '/api/books';
    if(this.props.search){
      address += '?title=' + this.props.search;
    }
    fetch(address).then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        cards: json.books
      });
      bookQuant = json.books.length;
    });
  }

  componentDidUpdate(prevProps) {
    if(prevProps.search !== this.props.search) {
      fetch("/api/books?title=" + this.props.search).then(response => {
        return response.json();
      }).then(json => {
        this.setState({
          cards: json.books
        });
        bookQuant = json.books.length;
      });
    }
  }

  handleClick = (direction) => {
    this.setState({ isMoved: true });
    if(windowWidth >= 500) {
      let distance = this.listRef.current.getBoundingClientRect().x -10.9;
      if(direction === "left" && this.state.sliderNumber > 0) { 
        this.setState({ sliderNumber: this.state.sliderNumber - 1, disable: true, IsMoved: false });
        setTimeout(() => this.setState({ sliderNumber: this.state.sliderNumber - 1, disable: false }), 300);
        this.listRef.current.style.transform = `translateX(${102.8 + distance}px)`
      }
      if(direction === "right" && this.state.sliderNumber < bookQuant*2) {
        this.setState({ sliderNumber: this.state.sliderNumber + 1, disable: true });
        setTimeout(() => this.setState({ sliderNumber: this.state.sliderNumber + 1, disable: false }), 300);
        this.listRef.current.style.transform = `translateX(${-202.8 + distance}px)`
      } 
    }
    if(windowWidth < 500) {
      let distance = this.listRef.current.getBoundingClientRect().x -10.9;
      if(direction === "left" && this.state.sliderNumber > 0) { 
        this.setState({ sliderNumber: this.state.sliderNumber - 1, disable: true, IsMoved: false });
        setTimeout(() => this.setState({ sliderNumber: this.state.sliderNumber - 1, disable: false }), 300);
        this.listRef.current.style.transform = `translateX(${134.9 + distance}px)`
      }
      if(direction === "right" && this.state.sliderNumber < bookQuant*2) {
        this.setState({ sliderNumber: this.state.sliderNumber + 1, disable: true });
        setTimeout(() => this.setState({ sliderNumber: this.state.sliderNumber + 1, disable: false }), 300);
        this.listRef.current.style.transform = `translateX(${-106.9 + distance}px)`
      } 
    }
  }
    

//To translate the whole row do 1428 and -1428
//For React-Native 205 and -205 to shift by one book 
//translate => transform: [{ translateX: -550 }] 


  render() {
    var rows = this.state.cards.map((card) => <BookTemplates isLoggedIn = {this.props.isLoggedIn} details={card}/>);
    return (
      /*<div className= "all-rows">
      <ScrollView scrollEventThrottle={16} style={styles.rowAndTitleContainer}>
          <div className="category-headers">
            {this.props.title}
          </div>
          <View style={styles.rowOuterContainer}>
            <button className="slider-arrow-left" 
            onClick={() => this.handleClick("left")} 
            disabled= {this.state.disable}
            style={{ display: !this.state.isMoved && "none" }}>&lt;</button>
            <ScrollView showsHorizontalScrollIndicator={false} horizontal={true}
            style={styles.rowInnerContainer}>
              <ScrollView showsHorizontalScrollIndicator={false} horizontal={true} ref={this.listRef}
              style={styles.rowScroller}>
                <BookTemplates imageUri={require("../../images/HPpage.jpg")}
                name="Harry Potter and the Philosopher's Stone" distance="5 miles"
                />
                <BookTemplates imageUri={require("../../images/MobyDick.jpg")}
                name="Moby Dick" distance="5 miles"
                />
                <BookTemplates imageUri={require("../../images/GoT.jpg")}
                name="Game of Thrones" distance="6.5 miles"
                />
                <BookTemplates imageUri={require("../../images/CoS.jpg")}
                name="Harry Potter and the Chamber of Secrets" distance="8 miles"
                />
                <BookTemplates imageUri={require("../../images/PoA.jpg")}
                name="Harry Potter and the Prisoner of Azkaban" distance="9 miles"
                />
                <BookTemplates imageUri={require("../../images/GoF.jpg")}
                name="Harry Potter and the Goblet of Fire" distance="11 miles"
                />
                <BookTemplates imageUri={require("../../images/OotP.jpg")}
                name="Harry Potter and the Order of the Phoenix" distance="15 miles"
                />
                <BookTemplates imageUri={require("../../images/HbP.jpg")}
                name="Harry Potter and the Half Blood Prince" distance="15 miles"
                />
                <BookTemplates imageUri={require("../../images/DH.jpg")}
                name="Harry Potter and the Deathly Hallows" distance="25 miles"
                />
                </ScrollView>
            </ScrollView>
            <button className="slider-arrow-right" 
            onClick={() => this.handleClick("right")} 
            disabled= {this.state.disable}>&gt;</button>
          </View>
      </ScrollView>
    </div>*/
    <div className= "all-rows">
    <div className="row-and-title-container">
        <div id="category-headers" className="category-headers">
          {this.props.title}
        </div>
        <div className="row-outer-container">
        
        <ScrollView showsHorizontalScrollIndicator={false} horizontal="true"
            style={styles.rowInnerContainer}>
        <button className="slider-arrow-left" 
        onClick={() => this.handleClick("left")} 
        disabled= {this.state.disable}
        style={{ display: !this.state.isMoved && "none" }}>&lt;</button>
            <div className="row-scroller" horizontal="true" ref={this.listRef}>
              {rows}
              </div>
              {(bookQuant <= 9 && windowWidth >= 1535) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 8 && windowWidth >= 1285) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 7 && windowWidth >= 1130.4) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 6 && windowWidth >= 979) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 5 && windowWidth >= 826.4) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 4 && windowWidth >= 674.4) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 3 && windowWidth >= 521.6) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant <= 3) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}
                style={{ display: true && "none" }}>&gt;</button>}
              {(bookQuant > 9 && windowWidth > 1535) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
              {(bookQuant >= 8 && windowWidth < 1456 && windowWidth >= 1130.4) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
              {(bookQuant >= 7 && windowWidth < 1130.4 && windowWidth >= 979) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
              {(bookQuant >= 6 && windowWidth < 979 && windowWidth >= 826.4) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
              {(bookQuant >= 5 && windowWidth < 826.4 && windowWidth >= 674.4) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
              {(bookQuant >= 4 && windowWidth < 674.4 && windowWidth >= 521.6) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
              {(bookQuant >= 3 && windowWidth < 521.6) && <button className="slider-arrow-right" 
                onClick={() => this.handleClick("right")} 
                disabled= {this.state.disable}>&gt;</button>}
          </ScrollView>

        </div>
    </div>
  </div>
    );
  }
}

const styles = {
  rowAndTitleContainer: {
    overflow: "hidden", 
    paddingBottom: "0px",
  },
  rowOuterContainer: {
    overflow: "hidden", 
    height: 452, 
    paddingLeft: 27, 
    backgroundColor: "#e9e7e0",
  },
  
  rowInnerContainer: {
    backgroundColor:"#d9d7d0", 
    overflow: "hidden",
    margin: 7.9, 
    marginRight: 0, 
    paddingLeft: 0,
    position: 'relative', 
    height: 346.5, 
    borderWidth: 2, 
    borderColor: "#555555",
  },
  /*rowInnerContainer: {
    backgroundColor:"#d9d7d0", 
    overflow: "hidden",
    margin: 7.9, 
    marginRight: 0, 
    paddingLeft: 15, 
    position: 'relative', 
    height: 435, 
    borderWidth: 2, 
    borderColor: "#555555",
  },*/
  rowScroller: {
    padding: 7.9, 
    backgroundColor:"#d9d7d0", 
    overflow: "hidden", 
    position: "relative",
    height: 500, 
    transform: [{ translateX: 0 }], 
    transition: "all 0.3s ease"
  }
}


export default BookRow;