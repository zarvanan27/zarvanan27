import React, { Component } from 'react';
import './BookTemplates.css';
//import { StyleSheet } from 'react-native';
import { Link } from 'react-router-dom';

class BookTemplates extends Component {
  render() {
    return (
      <Link to={this.props.isLoggedIn ? "/book/"+ this.props.details.id : "/sign-in"} style={{ textDecoration: "none" }}>
      <div className="book-poster">
        <div className="book-container">
            <div className="book-image-container">
              <img className="book-image" src={this.props.details.image} alt={this.props.details.title} /*style={styles.bookImage}*//>
            </div>
            <div className="book-text-container" horizontal="false">
              <p id="book-text" className="book-text">{this.props.details.title}<br/><br/>{this.props.distance}</p>
            </div>
        </div>
      </div>
      </Link>  
     /* <Link to="../pages/BookPage" style={{ textDecoration: "none" }}>
      <div className="book-poster">
        <View style={styles.bookContainer}>
            <View style={styles.bookImageContainer}>
              <Image source={this.props.imageUri} style={styles.bookImage}/>
            </View>
            <View style={styles.bookTextContainer}>
              <Text style={styles.bookText}>{this.props.name}</Text>
            </View>
        </View>
      </div>
      </Link>  */
    )
  }
}

/*const styles = StyleSheet.create({
  bookContainer: {
    height: 390, 
    width: 180,
  },
  bookImageContainer: {
    height: 273,
  },
  bookImage: {
    height: "100%",
    width: "100%",
    flex: 1, 
    width: null,
    resizeMode: "cover", 
    height: 275,
  },
  bookTextContainer: {
    height: 70, 
    paddingLeft: 10,
    paddingTop: 10, 
    paddingBottom: 10,
  },
  bookText: {
    fontWeight: 500,
  }
})*/

export default BookTemplates;
