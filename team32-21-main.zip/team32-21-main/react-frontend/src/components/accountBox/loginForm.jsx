import React, { useContext } from "react";

import {
  BoldLink,
  BoxContainer,
  FormContainer,
  Input,
  MutedLink,
  SubmitButton,
} from "./common";
import { Marginer } from "../marginer";
import { AccountContext } from "./accountContext";
import { useNavigate } from "react-router-dom";


export function LoginForm(props) {
  const { switchToSignup , switchToForgetPassword} = useContext(AccountContext);   
  let navigate = useNavigate();

  function handleSubmit(event) {
    event.preventDefault();
    var formData = new FormData();
    formData.append('email', event.target.elements.email.value);
    formData.append('password', event.target.elements.password.value);
    fetch('/api/users/login', {
      method: 'POST',
      body: formData,
    })
      .then(function(response){
        if (!response.ok) {
          alert("Incorrect username/password");
          return Promise.reject();
        } else {
          return response.json();
        }
      }).then(json => {
        console.log('Success:', json);
        props.setToken(json.token);
        props.setUserID(json.userid);
        props.logIn(true);
        navigate('/', {replace: true });
      })

    return false;
  }
  return (
    <BoxContainer> 
      <FormContainer onSubmit={handleSubmit} id="loginForm" method="post">
        <Input type="email" name="email" placeholder="Email" />
        <Input type="password" name="password" placeholder="Password" /> 
      </FormContainer>
      <Marginer direction="vertical" margin={10} />
      <MutedLink href="#" onClick={switchToForgetPassword}>
           Forgot Password?  
        </MutedLink>
      <Marginer direction="vertical" margin="1.6em" />
      
      <SubmitButton type="submit" form="loginForm">Sign In</SubmitButton>
      <Marginer direction="vertical" margin="1em" />
      <MutedLink href="#">
        Don't have an account?{" "}
        <BoldLink href="#" onClick={switchToSignup}>
          Sign up
        </BoldLink>
      </MutedLink>
    </BoxContainer>
  );
}
