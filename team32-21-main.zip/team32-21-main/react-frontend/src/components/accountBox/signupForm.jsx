import React, { useContext } from "react";
import {
  BoldLink,
  BoxContainer,
  FormContainer,
  Input,
  MutedLink,
  SubmitButton,
} from "./common";
import { Marginer } from "../marginer";
import { AccountContext } from "./accountContext";
import { useNavigate } from "react-router-dom";

export function SignupForm(props) {
  const { switchToSignin } = useContext(AccountContext);
  let navigate = useNavigate();

  function handleSubmit(event) {
    console.log("It's working...");
    event.preventDefault();
    var formData = new FormData();
    formData.append('email', event.target.elements.email.value);
    formData.append('password', event.target.elements.password.value);
    formData.append('name', event.target.elements.name.value);
    fetch('/api/users/create', {
      method: 'POST',
      body: formData,
    })
      .then(function(response){
        if (!response.ok) {
          alert("There was an error. Please try again.");
          return Promise.reject();
        } else {
          return response.json();
        }
      }).then(json => {
        console.log('Success:', json);
        props.setToken(json.token);
        props.setUserID(json.userid);
        props.logIn(true);
        navigate('/', {replace: true });
      })

    return false;
  }

  return (
    <BoxContainer>
      <FormContainer onSubmit={handleSubmit} id="signupForm" method="post">
        <Input type="text" placeholder="Full Name" name="name"/>
        <Input type="email" placeholder="Email" name="email"/>
        <Input type="password" placeholder="Password" name="password"/>
        <Input type="password" placeholder="Confirm Password" name="confirm"/>
      </FormContainer>
      <Marginer direction="vertical" margin={10} />
      <MutedLink href="#"> I agree to <a href="https://bham-my.sharepoint.com/personal/hxb202_student_bham_ac_uk/Documents/Team%2032-21/m2/Library%20of%20Peers%20GDPR%20Privacy%20Policy.htm?csf=1&web=1&e=K8TfRi">terms and conditions</a></MutedLink> <input type= "checkbox" />
      <Marginer direction="vertical" margin={10} />
      <SubmitButton type="submit" form="signupForm">Sign Up</SubmitButton>
      <Marginer direction="vertical" margin="1em" />
      <MutedLink href="#">
        Already have an account?
        <BoldLink href="#" onClick={switchToSignin}>
           SignIn 
        </BoldLink>
      </MutedLink>
    </BoxContainer>
  );
}
