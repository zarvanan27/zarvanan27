import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import logo from "../lop-logo-new.png";
import { Form } from 'react-bootstrap';
import Calendar from './popups/Calendar';
import Notifications from './popups/Notifications';
import Borrowed from './popups/Borrowed';
import Preferences from './popups/Preferences'
import './popups/Calendar.css'
import './SignedInNavbar.css';
import { useNavigate } from "react-router-dom";

function SignedInNavbar(props) {
  const [click, setClick] = useState(false);
  const [keyPress, setKeyPress] = useState(false);
  const [calClick, setCalClick] = useState(false);
  const [calKeyPress, setCalKeyPress] = useState(false);
  const [notifClick, setNotifClick] = useState(false);
  const [notifKeyPress, setNotifKeyPress] = useState(false);
  const [borClick, setBorClick] = useState(false);
  const [borKeyPress, setBorKeyPress] = useState(false);
  const [prefClick, setPrefClick] = useState(false);
  const [prefKeyPress, setPrefKeyPress] = useState(false);
  const [open, setOpen] = useState(false);
  let navigate = useNavigate();
  const [searchterm, setSearchTerm] = useState(" ");

  function handleSearch(e) {
    e.preventDefault();
    navigate('/search/' + searchterm, {replace: true });
  }

  function onSearchChange(e) {
    setSearchTerm(e.target.value);
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      setKeyPress(!keyPress);
      setClick(!click);
    }
  }

  const handleClick = () => {
    setKeyPress(!keyPress);
    setClick(!click);
  }

  const handleClickCalendar = () => {
    setCalClick(!calClick);
    setCalKeyPress(!calKeyPress);
    setNotifKeyPress(false);
    setBorKeyPress(false);
    setPrefKeyPress(false);
    setNotifClick(false);
    setBorClick(false);
    setPrefClick(false);
    setOpen(!open);
    setClick(false);
    setKeyPress(false);
  }
  const handleClickNotifications = () => {
    setNotifClick(!notifClick);
    setNotifKeyPress(!notifKeyPress);
    setCalKeyPress(false);
    setBorKeyPress(false);
    setPrefKeyPress(false);
    setCalClick(false);
    setBorClick(false);
    setPrefClick(false);
    setOpen(!open);
    setClick(false);
    setKeyPress(false);
  }
  const handleClickBorrowed = () => {
    setBorClick(!borClick);
    setBorKeyPress(!borKeyPress);
    setNotifKeyPress(false);
    setCalKeyPress(false);
    setPrefKeyPress(false);
    setNotifClick(false);
    setCalClick(false);
    setPrefClick(false);
    setOpen(!open);
    setClick(false);
    setKeyPress(false);
  }
  const handleClickPreferences = () => {
    setPrefClick(!prefClick);
    setPrefKeyPress(!prefKeyPress);
    setNotifKeyPress(false);
    setBorKeyPress(false);
    setCalKeyPress(false);
    setBorClick(false);
    setNotifClick(false);
    setCalClick(false);
    setOpen(!open);
    setClick(false);
    setKeyPress(false);
  }
  const closeMobileMenu = () => {
    setOpen(!open)
    setClick(false);
   
  }

/*<Link to="/" className='nav-links' onClick={handleClickBorrowed}>
   Borrowed
  </Link>*/

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          <Link to="/" className="navbar-logo" onClick={closeMobileMenu}>
            <img className="lop" src={logo} alt="Library of Peers"/>
          </Link>
          <div className="search-bar-container">
          <Form className="search-bar-form" onSubmit={handleSearch}>
            <input className="search-bar" type="text" placeholder="Search for Books..." onChange={onSearchChange}/>
          </Form>
          </div>
          <div tabIndex={"0"} className="menu-icon" onClick={handleClick} onKeyPress={handleKeyDown}>
            <p style={{marginTop: "10px"}}>
              <i className={click || keyPress ? "fas fa-times" : "fas fa-bars"} />
            </p>
          </div>
          <ul className={click || keyPress ? "nav-menu-signed-in active" : "nav-menu-signed-in"}>
            <li className='nav-item'>
              <div className="dropdown-calendar">
                <button className={click || keyPress ? "btn-nav--outline active" : "btn-nav--outline"} id="btn-nav--outline" onClick={handleClickCalendar}>
                  Calendar
                </button>
                <div className={calClick || calKeyPress ? "dropdown-content-calendar-appear" : "dropdown-content-calendar"}>
                  <Calendar token={props.token} userid={props.userid}/>
                </div>
              </div>
            </li>
            <li className='nav-item'>
              <div className="dropdown-notifications">
                <button className={click || keyPress ? "btn-nav--outline active" : "btn-nav--outline"} id="btn-nav--outline" onClick={handleClickNotifications}>
                  Notifications
                </button>
                <div className={notifClick || notifKeyPress ?  "dropdown-content-notifications-appear" : "dropdown-content-notifications"}>
                  <Notifications token={props.token} userid={props.userid}/>
                </div>
              </div>
            </li>
            <li className='nav-item'>
              <div className="dropdown-borrowed">
                <button className={click || keyPress ? "btn-nav--outline active" : "btn-nav--outline"} id="btn-nav--outline" onClick={handleClickBorrowed}>
                  Borrowed
                </button>
                <div className={borClick || borKeyPress ? "dropdown-content-borrowed-appear" : "dropdown-content-borrowed"}>
                  <Borrowed token={props.token} userid={props.userid}/>
                </div>
              </div>  
            </li>
            <li className='nav-item'>
              <div className="dropdown-preferences">
                <button className={click || keyPress ? "btn-nav--outline active" : "btn-nav--outline"} id="btn-nav--outline" onClick={handleClickPreferences}>
                  Font Size
                </button>
                <div className={prefClick || prefKeyPress ? "dropdown-content-preferences-appear" : "dropdown-content-preferences"}>
                  <Preferences />
                </div>
              </div>
            </li>
            <li className='nav-item'>
              <div className="profile-container">
                <Link to="/profile" className={click || keyPress ? "btn-nav-profile--outline active" : "btn-nav-profile--outline"} id="btn-nav--outline" onClick={closeMobileMenu} style={{textDecoration: "none"}}>
                  Profile
                </Link>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </>
    )
}

export default SignedInNavbar;