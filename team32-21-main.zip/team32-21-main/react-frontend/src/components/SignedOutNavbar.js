import React, { useState } from 'react';
import {Link} from 'react-router-dom';
import logo from "../lop-logo-new.png";
import { Form } from 'react-bootstrap';
import './SignedOutNavbar.css';
import { useNavigate } from "react-router-dom";

function SignedOutNavbar() {
  const [click, setClick] = useState(false);
  const [keyPress, setKeyPress] = useState(false);

  let navigate = useNavigate();
  const [searchterm, setSearchTerm] = useState(" ");

  function handleSearch(e) {
    e.preventDefault();
    navigate('/search/' + searchterm, {replace: true });
  }

  function onSearchChange(e) {
    setSearchTerm(e.target.value);
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      setKeyPress(!keyPress);
      setClick(!click);
    }
  }

  const handleClick = () => {
    setKeyPress(!keyPress);
    setClick(!click);
  }

  const closeMobileMenu = () => setClick(false);

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          <Link to="/" className="navbar-logo" onClick={closeMobileMenu}>
            <img className="lop" src={logo} alt="Library of Peers"/>
          </Link>
          <div className="search-bar-container-so">
          <Form className="search-bar-form-so" onSubmit={handleSearch}>
            <input className="search-bar-so" type="text" placeholder="Search for Books..." onChange={onSearchChange}/>
          </Form>
          </div>
          <div className="menu-icon" tabIndex={"0"}  onClick={handleClick} onKeyPress={handleKeyDown}>
            <i className={click || keyPress ? "fas fa-times" : "fas fa-bars"} />
          </div>
          <ul className={click || keyPress ? "nav-menu-signed-out active" : "nav-menu-signed-out"}>
            <li className='nav-item-so'>
              <Link to="/sign-in" className={click || keyPress ? "btn-nav--outline active" : "btn-nav--outline"} id="btn-nav--outline" onClick={handleClick} style={{textDecoration:"none"}}>
                Sign In / Register
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </>
    )
}

export default SignedOutNavbar;