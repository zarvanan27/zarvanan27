import React, { Component } from 'react';
import './BookInfo.css';
import DropDown from '../DropDown';
import DropDownProfile from '../DropDownProfile';


class BookInfo extends Component {
  render(){
    return (
      <div className="container">
        <div className="book-info-wrapper">
          <div className="cover-container">
            <img className="book-cover" src={this.props.imageUri} alt={this.props.title} />
          </div>
          <div horizontal="false">
          <div className="info-container">
            <h1 id="bookpage-title" className="title">{this.props.title}</h1>
            <p id="bookpage-desc" className="desc">{this.props.desc}</p>
          </div>
          <div className="button-container">
              <DropDownProfile id={this.props.id} token={this.props.token} userid={this.props.userid} lender={this.props.lender} />
            </div>
          <div className="button-container">
            <DropDown id={this.props.id} token={this.props.token} userid={this.props.userid} lender={this.props.lender}/>
          </div>
          </div>
        </div>
      </div>
    );
  }
}//<Button buttonStyle="btn--outline">Request</Button>

export default BookInfo;
