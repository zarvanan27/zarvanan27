import "./Profile.css";
import { RatingStar} from 'rating-star';
import React from "react";

export default function Profile(props) {
    const [rating, setRating] = React.useState(0);
  
    const onRatingChange = val => {
      setRating(val);
      fetch('/api/users/' + props.id + "/LenderRating", {
        method: 'POST',
        body: JSON.stringify({
          "rating_value": val,
          "token": props.token
        }),
      })
        .then(function(response){
          if (!response.ok) {
            alert("There was an error. Please try again.");
            return Promise.reject();
          } else {
            return response.json();
          }
        }).then(json => {
          console.log('Success:', json);
        });
    };

        return(
            <div className="container">
                <div className="wrapper"></div>
            <div horizontal="false">
            <div className="info-container">
                <h1 className="title">{props.name}</h1>
                <h2 className="email">{props.email}</h2>
                <h3 className="rating">{props.name}'s average rating</h3>
                <RatingStar
                id="non-clickable"
                rating={props.rating}
                />
                <h3 className="rating">Rate {props.name}</h3>
                <RatingStar
                id="clickable"
                clickable
                rating={rating}
                onRatingChange={onRatingChange}
                />
            </div>
            </div>
            </div>

        )
    }
