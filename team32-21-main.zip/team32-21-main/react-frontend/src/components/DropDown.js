import React, {useState} from 'react';
import './DropDown.css';

function DropDown(props) {

  function DropDownItem(subprops) {
    return(
      <p id="request-links" tabIndex={0} onClick={PostRequest} onKeyPress={KeyPostRequest}>{subprops.name}: {subprops.distance}</p>
    )
  }

  const [click, setClick] = useState(false);

  const handleClick = () => setClick(!click);

  function RequestSuccessful(){
    document.getElementById("request-confirmation").innerHTML = "Book Requested";
  }

  function KeyPostRequest(){
    setClick(!click);
    RequestSuccessful();
    console.log(props.userid);
    fetch('/api/reservations', {
      method: 'POST',
      body: JSON.stringify({"book_id":props.id, "token": props.token, "user_id":props.userid}),
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
    })
  }

  function PostRequest(){
    setClick(!click);
    RequestSuccessful();
    console.log(props.userid);
    fetch('/api/reservations', {
      method: 'POST',
      body: JSON.stringify({"book_id":props.id, "token": props.token, "user_id":props.userid}),
    })
    .then(response => response.json())
    .then(data => {
      console.log('Success:', data);
    })
  }

  var dropdowns = props.lender.map((lender) => <DropDownItem name = {lender.name} distance={lender.distance}/>);
  
  return (
  <div className="dropdown-request">
    <button id="request-links" className='request-links' onClick={handleClick}>
      Request
    </button>
    <p id="request-confirmation" className="req-con"></p>
    <div className={click ? "dropdown-content-appear" : "dropdown-content"}>
      {dropdowns}
    </div>
  </div>
  );
}
 
export default DropDown
