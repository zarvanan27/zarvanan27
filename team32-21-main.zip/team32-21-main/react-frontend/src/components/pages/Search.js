import React from 'react';
import '../../App.css';
import "./Home.css";
import BookRow from "../home/BookRow";

function Search(props) {
  return (
    <>
      <BookRow isLoggedIn = {props.isLoggedIn} title={"Search Results: " + props.search} search={props.search}/>
    </>
  );
}

export default Search;