import React, { useState } from 'react';
import './profileScreen.css';
import { Button } from '../Button';
import { useNavigate } from "react-router-dom";

function ProfileScreen(props) {
  const [submitting, setSubmitting] = useState(false);
  const [isbn, setISBN] = useState(" ");
  const [confirming, setConfirming] = useState("");
  const [details, setDetails] = useState({"name": "", "email": "", "password": "", "confirm": "", "address": ""});
  let navigate = useNavigate();

  function onISBNChange(e) {
    setISBN(e.target.value);
  }

  function onDetailsChange(e) {
    var currentDetails = details;
    currentDetails[e.target.name] = e.target.value;
    setDetails(currentDetails);
  }

  function handleCreate() {
    fetch('/api/books', {
      method: 'POST',
      body: JSON.stringify({
        "title": confirming.title,
        "description": "By " + confirming.author,
        "image": confirming.image,
        "token": props.token
      }),
    })
      .then(function(response){
        if (!response.ok) {
          alert("There was an error. Please try again.");
          return Promise.reject();
        } else {
          return response.json();
        }
      }).then(json => {
        console.log('Success:', json);
        alert("Book upload successful!");
        navigate('/', {replace: true });
      });
  }

  const handleSubmit = event => {
    event.preventDefault();
   setSubmitting(true);

   fetch('/api/books/isbn/' + isbn)
  .then(response => response.json())
  .then(data => {
    console.log('Success:', data);
    setConfirming(data);
   });
  }

  const titleArr = [<p id="btn--outline" style={{backgroundColor:"#b9b7b0"}}>Confirm book title: </p>, <br />]

  const [submittingDetails, setSubmittingDetails] = useState(false);
  const handleSubmitDetails = event => {
    event.preventDefault();
    if(details.password !== details.confirm) {
      alert("Passwords must match!");
    } else {
      setSubmittingDetails(true);

      fetch('/api/users/' + props.userid, {
        method: 'PUT',
        body: JSON.stringify({
          "name": details.name,
          "email": details.email,
          "password": details.password,
          "address": details.address,
          "token": props.token
        }),
      })
        .then(function(response){
          if (!response.ok) {
            alert("There was an error. Please try again.");
            return Promise.reject();
          } else {
            return response.json();
          }
        }).then(json => {
          console.log('Success:', json);
          alert("Profile edited successfully!");
          setSubmittingDetails(false);
        });
    }
  }

  return(
    <div className="wrapper">
      <div className="container">
      <form className="form" onSubmit={handleSubmitDetails}>
      <p className="book-upload-heading">Edit Profile</p>
        <fieldset className="update-fields-fieldset">
          <label>
            <div className="update-fields-container">
              <p className="input-headings" id="input-headings">Name</p>
              <input name="name" onChange={onDetailsChange}/>
            </div>
            <div className="update-fields-container">
              <p className="input-headings" id="input-headings">Email</p>
              <input name="email" onChange={onDetailsChange}/>
            </div>
            <div className="update-fields-container">
              <p className="input-headings" id="input-headings">New Password</p>
              <input type="password" name="password" onChange={onDetailsChange}/>
            </div>
            <div className="update-fields-container">
              <p className="input-headings" id="input-headings">Confirm new password</p>
              <input name="confirm" type="password" onChange={onDetailsChange}/>
            </div>
            <div className="update-fields-container">
              <p className="input-headings" id="input-headings">Address</p>
              <input name="address" onChange={onDetailsChange}/>
            </div>
            <div className="update-button-container"> 
              <Button buttonStyle="btn--outline" type="submit">Update</Button>
            </div>
            {submittingDetails && <p className="uploading-book" id="input-headings">Submtting Form...</p>}
          </label>
        </fieldset>
      </form>  
      <form className="form" onSubmit={handleSubmit}>
        
        <p className="book-upload-heading" id="book-upload-heading">Upload your book</p>
        <fieldset className="fieldset">
          <div className="labels">
            <h1 className="adding-ISBN" id="adding-ISBN">Book ISBN</h1>
          </div>
          <label className="ISBN-label">
            <input book="book ISBN" onChange={onISBNChange}/>
            {submitting &&
            <h1 className="uploading-book" id="uploading-book">Uploading book...</h1>}
            </label>
          <div className="add-button-container"> 
            <Button buttonStyle="btn--outline" type="submit" id="btn--outline">Add</Button>
          </div>
          {submitting && <p className="confirm-title" id="input-headings">{titleArr} {confirming.title}</p>}
          
          {submitting && <Button buttonStyle="btn--outline" id="btn--outline" onClick={handleCreate}>Submit Book</Button>}
    
        </fieldset>
        </form>
      </div>
    </div>
  )
}

export default ProfileScreen;



