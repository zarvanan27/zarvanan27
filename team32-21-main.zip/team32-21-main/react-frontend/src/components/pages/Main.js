import React from 'react';
import SignedOutNavbar from '../SignedOutNavbar';
import SignedInNavbar from '../SignedInNavbar';
import SignedOutFooter from '../SignedOutFooter';
import SignedInFooter from '../SignedInFooter';
import Home from './Home';
import { Routes, Route, useParams } from "react-router-dom";
import BookPage from './BookPage';
import Search from './Search';
import ProfileScreen from './profileScreen';
import Lender from './Lender';

function Main(props) {
  return (
    <>
      {props.isLoggedIn ? <SignedInNavbar token={props.token} userid={props.userid}/> : <SignedOutNavbar />}
            <Routes>
                <Route path="/" element={<Home isLoggedIn={props.isLoggedIn}/>}/>
                <Route path="/book/:id" element={<RoutedBookPage token={props.token} userid={props.userid}/>}/>
                <Route path="/search/:search" element={<RoutedSearch isLoggedIn={props.isLoggedIn}/>}/>
                <Route path="/profile" element={<ProfileScreen token={props.token} userid={props.userid}/>}/>
                <Route path="/lender/:id" element={<RoutedLender token={props.token} userid={props.userid}/>}/>
            </Routes>
      {props.isLoggedIn ? <SignedInFooter/> : <SignedOutFooter />}
      
    </>
  );
}

function RoutedBookPage(props) {
    let { id } = useParams();
    return (
        <BookPage id={id} token={props.token} userid={props.userid}/>
    );
}

function RoutedLender(props) {
  let { id } = useParams();
  return (
    <Lender token={props.token} userid={props.userid} id={id}/>
  );
}

function RoutedSearch(props){
  let { search } = useParams();
  return (
    <Search isLoggedIn = {props.isLoggedIn} search = {search}/>
  );
}

export default Main;
