import React from 'react';
import '../../App.css';
import "./Home.css";
import BookRow from "../home/BookRow";

function Home(props) {
  return (
    <>
      <BookRow isLoggedIn = {props.isLoggedIn} title="Books Near You" />
      <BookRow isLoggedIn = {props.isLoggedIn} title="Fantasy" />
      <BookRow isLoggedIn = {props.isLoggedIn} title="Action" />
    </>
  );
}

export default Home;