import React, { Component } from 'react';
import BookInfo from '../bookpage/BookInfo';
import styled from "styled-components";

const Container = styled.div``;

class BookPage extends Component {
  // Called when component is first created
  constructor(props) {
    super(props);

    this.state = {
      title: "Loading...",
      description: "Loading...",
      image: "Loading",
      lender: [{"name": "Loading...", "distance": "Loading..."}]
    }
  }

  // Called when component is loaded
  componentDidMount() {
    fetch('/api/books/' + this.props.id).then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        title: json.title,
        description: json.description,
        image: json.image,
      })
    });
    fetch('/api/books/' + this.props.id + "/owner").then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        lender: [{"name": json.name, "distance": "2 miles"}],
      })
    });
  }

  render(){
    return (
      <Container>
        <BookInfo imageUri={this.state.image}
        title={this.state.title} desc={this.state.description} id={this.props.id} token={this.props.token} userid={this.props.userid} lender={this.state.lender}/>
      </Container>
    );
  }
}

export default BookPage;
