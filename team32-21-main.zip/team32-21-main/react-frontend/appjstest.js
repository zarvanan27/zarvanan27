import './bookpage.css';
import React from 'react';
import useVH from 'react-viewport-height';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter as Router } from "react-router-dom";
import { NavigationBar } from "./components/NavigationBar";
import styled from 'styled-components';
//import { Dimensions, Platform, PixelRatio } from 'react-native';

function BookPage() {
  useVH();


  //Attempt to make screen size responsive but very slow
  /*const [dimensions, setDimensions] = React.useState({ 
    height: window.innerHeight,
    width: window.innerWidth
  })
  
  React.useEffect(() => {
    function handleResize() {
      setDimensions({
        height: window.innerHeight,
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize)
  })

  const Hptitle = () => (
    <h1 className="hptitle" style={{fontSize:dimensions.width * 0.023}}>
      Harry Potter and the Philosopher's Stone</h1>
  );*/

  return(
    <>
      <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0"></meta>
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"></link>

      <React.Fragment>
        <Router>
          <NavigationBar />
        </Router>
      </React.Fragment>
      
      <Format>
        <section className="book-page-info" style={{flex:1,alignItems:'center',justifyContent:'center',alignSelf:'stretch'}}>
          <div className="book-info" style={{display:"flex",flexDirection:"row"}}>
            <bookcoversect>
              <section className="bookcover-border">
                <Bookcover />
              </section>
            </bookcoversect>

            <article className="book-data"style={{display:"flex",flexDirection:"column"}}>
              <bookinfosect>
                <section className="bookinfo-border">
                  <Booktitle />
                  <Bookdescr />
                </section>
              </bookinfosect>
              

              <requestbtn>
                <Borrowbtn />
              </requestbtn>
            </article>
          </div>
        </section>
      </Format>
    </>
  )
}
/*<section className="book-data" height="100%" style={{display:"flex",flexDirection:"column"}}>
  <Hptitle />
  <Hpblurb />
</section>*/

//const width = Dimensions.get('window').width;
//const height = Dimensions.get('window').height;

const Format = styled.div`
  bookcoversect { 
    float: left;
    height: 629px;
    width: 30%;
    background: #d1d1d1;
    padding: 20px;
  }

  bookinfosect {
    float: left;
    height: 100%;
    width: 100%;
    background: #d1d1d1;
    padding: 20px;
  }

  bookdescrsect {
    float: top;
    height: 200px;
    width: 100%;
    background: #d1d1d1;
    padding: 20px;
  }

  requestbtn {
    width:100%;
    float: left;
  }

`;

const Bookcover = (props) => (
  <img
    className="bookcover" src="https://images-na.ssl-images-amazon.com/images/I/51mtZy7oJVL.jpg" alt="Harry Potter and the Philosopher's Stone"
  />
);

const Booktitle = (props) => (
  <h1 className="booktitle">
    {props.title}</h1>
);

const Bookdescr = (props) => (
  <p className="bookdescr">
    Harry Potter thinks he is an ordinary boy - until he is rescued by an owl, <br/>
    taken to Hogwarts school for witchcraft and wizardry, learns to play <br/>
    Quidditch and does battle in a deadly duel. The reason........ <br/>HARRY POTTER IS A WIZARD!
  </p>
);

//style={{position:"relative",left:250,top:20}}
const Borrowbtn = () => (
  <section className="borrowbtnsection">
    <a href="/" className="borrowbtn" color="black">Request From Mark</a>
  </section>
);

export default BookPage;
