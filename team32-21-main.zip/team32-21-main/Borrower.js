import React, { Component } from 'react';
import Profile from '../profile/Profile';
import styled from "styled-components";
//import { RatingStar} from 'rating-star';

const Container = styled.div``;

class Lender extends Component {
  // Called when component is first created
  constructor(props) {
    super(props);

    this.state = {
      name: "Loading...",
      email: "Loading...",
      rating: "Loading..."
    }
  }

  // Called when component is loaded
  componentDidMount() {
    fetch('/api/users/' + this.props.id).then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        name: json.name,
        email: json.email,
      })
    });
    fetch('/api/users/' + this.props.id + "/borrowerRating").then(response => {
      return response.json();
    }).then(json => {
      this.setState({
        borrower_rating: json.borrower_rating,
      })
    });
  }

  
  render(){
    return (
      <Container>
        <Profile 
        name={this.state.name} email={this.state.email} rating={this.state.borrower_rating}/>
      </Container>
    );
  }
}

export default Lender;

