import json
import urllib.request

def getISBNData(isbn):
    with urllib.request.urlopen(f"https://openlibrary.org/api/books?bibkeys=ISBN:{isbn}&jscmd=data&format=json") as response:
        jsonstring = response.read()
        jsondict = json.loads(jsonstring)
        if len(jsondict) == 0:
            raise FileNotFoundError("Invalid ISBN / Book details not found")
        data = list(jsondict.values())[0]
        title = data['title']
        author = data['authors'][0]['name']
        image = ""
        try:
            image = data['cover']['large']
        except KeyError:
            image = "https://picsum.photos/1600/1000"
        return {'title': title, 'author': author, 'image': image}