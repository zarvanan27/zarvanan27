import datetime
import random
import json
from flask import Flask, request, Response
from flask_sqlalchemy import SQLAlchemy
from os import getenv
from flask_migrate import Migrate
from .isbn import getISBNData
from .mail import send_simple_message
from passlib.hash import sha256_crypt

app = Flask(__name__)
dbhost = getenv("DATABASE_HOST")
dbname = getenv("POSTGRES_DB")
if dbhost is None:
    dbhost = "localhost" # fallbacks for easy deployment
if dbname is None:
    dbname = "lop"
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:"password"@' + dbhost + '/' + dbname
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

migrate = Migrate(app, db)

# Code above here is all config
# Models (tables)
class Book(db.Model):
    id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    title = db.Column(db.String(240))           # Book Title
    description = db.Column(db.String(1000))    # Blurb
    image = db.Column(db.String(1000))          # Link to an image file
    reservations = db.relationship('Reservation', backref='book')
    owner = db.Column(db.Integer, db.ForeignKey("users.id"))
    owner_rel = db.relationship("Users", foreign_keys=[owner])

class Users(db.Model):
    id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    name = db.Column(db.String(240))
    email = db.Column(db.String(240))
    password = db.Column(db.String(240))

class Reservation(db.Model):
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, primary_key = True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False, primary_key = True)
    date = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    book_rel = db.relationship("Book", foreign_keys=[book_id])

class Borrowed(db.Model):
    borrower = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False, primary_key = True)
    dateBorrowed = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    book_rel = db.relationship("Book", foreign_keys=[book_id])

class LoginTokens(db.Model):
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, primary_key = True)
    token = db.Column(db.Integer)
    lastUse = db.Column(db.DateTime, default=datetime.datetime.utcnow)

class LenderRatings(db.Model):
    rate_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    rating_userid = db.Column(db.Integer, db.ForeignKey('users.id'))
    rated_userid = db.Column(db.Integer, db.ForeignKey('users.id'))
    rating_value = db.Column(db.Integer)

class BorrowerRatings(db.Model):
    rate_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    rating_userid = db.Column(db.Integer, db.ForeignKey('users.id'))
    rated_userid = db.Column(db.Integer, db.ForeignKey('users.id'))
    rating_value = db.Column(db.Integer)


db.create_all()

# Helper functions
def model_to_dict(dbItem):
    dicted = dbItem.__dict__
    dicted.pop("_sa_instance_state", None)
    return dicted

def token_to_user_id(tokenToCheck):
    userToCheck = LoginTokens.query.filter_by(token = tokenToCheck)
    if userToCheck.count() == 0:
        return False
    else:
        userToCheck = userToCheck.first()
        return userToCheck.user_id

def logInCheck(tokenToCheck):
    #Checks to see if a user's still logged in
    #Sends True if it's been less than ten minutes since last user POST request, updates table to reflect latest request
    #Sends False if it's been ten or more minutes since last user POST request, removes user's row from table
    currentTime = datetime.datetime.utcnow()
    userToCheck = LoginTokens.query.filter_by(token = tokenToCheck)
    if userToCheck.count() == 0: #If user's not in the logged in table, return false
        return False
    userToCheck = userToCheck.first()
    #If user's in the log in table, check whether their last action was less than 10 mins ago
    lastUsedTime = userToCheck.lastUse
    timeChange = currentTime-lastUsedTime
    if timeChange.seconds < 600: #If the user's had an action within the time limit, let them in and update the 'lastUsed' column
        userToCheck.lastUse = datetime.datetime.utcnow()
        db.session.commit()
        return True
    else: #If the user's not done anything for a while, kick them out and remove them from the logged in table.
        db.session.delete(userToCheck)
        db.session.commit()
        return False
        

# Views aka methods
@app.route("/")#Get home page
def index():
    return "<h1>Library of Peers</h1>"

@app.route("/api/books", methods=["GET", "POST"])
def books():
    if request.method == "GET":
        books = Book.query

        # Search by title: /api/books?title=xxx
        r_title = request.args.get("title", default=False)
        if r_title:
            books = books.filter(Book.title.ilike(f"%{r_title}%"))

        # Convert to list
        books = books.all()
        out = []
        for row in books:
            out.append(model_to_dict(row))
        toReturn = {"books": out}
        return toReturn

    elif request.method == "POST":
        data = request.form
        if data.get("token") == None:
            data = json.loads(request.data)

        if logInCheck(data["token"]) == False:
            return Response(status = 401)
        user = Users.query.filter_by(id = int(token_to_user_id(data["token"]))).first_or_404()
        newbook = Book(title = data['title'], description = data.get('description',""), image = data.get('image',"https://picsum.photos/1600/1000"), owner = user.id) # sample stock image as a backup
        db.session.add(newbook)
        db.session.commit()
        db.session.refresh(newbook)
        return model_to_dict(newbook)

@app.route("/api/books/<int:id>", methods=["GET", "PUT", "DELETE"])
def get_book(id):
    if request.method == "GET":
        books = Book.query.filter_by(id = id)
        specific = books.first_or_404()
        return model_to_dict(specific)
    elif request.method == "PUT":
        data = request.form
        books = Book.query.filter_by(id = id)
        specific = books.first_or_404()

        if logInCheck(data["token"]) == False:
            return Response(status = 401)
        if int(token_to_user_id(data["token"])) != specific.owner:
            return Response(status = 403)

        specific.title = data['title']
        specific.description = data['description']
        specific.image = data['image']
        db.session.commit()
        db.session.refresh(specific)
        return model_to_dict(specific)
    elif request.method == "DELETE":
        data = request.form
        books = Book.query.filter_by(id = id)
        specific = books.first_or_404()

        if logInCheck(data["token"]) == False:
            return Response(status = 401)
        if int(token_to_user_id(data["token"])) != specific.owner:
            return Response(status = 403)

        db.session.delete(specific)
        db.session.commit()
        return Response(status=204)

@app.route("/api/books/<int:id>/owner", methods=["GET"])
def get_book_owner(id):
    books = Book.query.filter_by(id = id)
    specific = books.first_or_404().owner_rel
    out = {'name': specific.name, 'id': specific.id}
    return out

@app.route("/api/books/isbn/<int:isbn>", methods=["GET"])
def get_isbn_data(isbn):
    values = {}
    try:
        values = getISBNData(isbn)
    except FileNotFoundError:
        return Response(status=404)
    return values

@app.route("/api/users/<int:id>", methods=["GET", "PUT", "DELETE", "POST"])         
def get_user(id):
    if request.method == "GET":
        users = Users.query.filter_by(id = id)
        specific = users.first_or_404()
        out = {'name': specific.name, 'id': specific.id, 'email': specific.email}
        return out
    elif request.method == "PUT":
        data = request.form
        if data.get("token") == None:
            data = json.loads(request.data)


        if logInCheck(data["token"]) == False:
            return Response(status = 401)
        if int(token_to_user_id(data["token"])) != id:
            return Response(status = 403)

        users = Users.query.filter_by(id = id)
        specific = users.first_or_404()
        specific.name = data['name']
        specific.email = data['email']
        specific.password = sha256_crypt.encrypt(data['password'])
        db.session.commit()
        db.session.refresh(specific)
        out = {'name': specific.name, 'email': specific.email, 'id': specific.id}
        return out
    elif request.method == "DELETE":
        if logInCheck(data["token"]) == False:
            return Response(status = 401)
        if int(token_to_user_id(data["token"])) != id:
            return Response(status = 403)

        users = Users.query.filter_by(id = id)
        specific = users.first_or_404()
        db.session.delete(specific)
        db.session.commit()
        return Response(status=204)

@app.route("/api/users")#Get list of users
def users():
    users = Users.query.all()
    out = []
    for row in users:
        out.append({'name': row.name})
    toReturn = {"users": out}
    return toReturn

@app.route("/api/users/create", methods = ['POST'])#Add new user to user table
def createUser():
    data = request.form
    password = sha256_crypt.encrypt(data['password'])
    newuser = Users(name = data['name'], email = data['email'], password = password)
    db.session.add(newuser)
    db.session.commit()
    db.session.refresh(newuser)
    send_simple_message(data['email'], "Welcome to Library of Peers", f"Hi {data['name']}! Thanks for signing up to Library of Peers.\nWe're glad to have you.")

    # Sign in, after sign up
    newToken = random.randint(0,999999999)
        
    newLogin = LoginTokens(user_id = newuser.id, token = newToken)

    db.session.add(newLogin)
    db.session.commit()
    db.session.refresh(newLogin)

    return {"token": newToken, "userid": newuser.id}

@app.route("/api/users/login", methods = ['POST'])#Log in users
def loginCheck():
    #Returns 404 if email isn't found
    #Returns 400 if password isn't correct
    #Returns the userid as a token, and 200 as a success message. The token is then used by the frontend to send requests from a specific user.
    data = request.form
    inputted = Users(name = "John", email = data['email'], password = data['password'])
    targetCreds = Users.query.filter_by(email = inputted.email).first_or_404()
    if sha256_crypt.verify(inputted.password, targetCreds.password):
        LoginTokens.query.filter_by(user_id = targetCreds.id).delete()
        db.session.commit()
        newToken = random.randint(0,999999999)
        
        newLogin = LoginTokens(user_id = targetCreds.id, token = newToken)
       
        db.session.add(newLogin)
        db.session.commit()
        db.session.refresh(newLogin)

        return {"token": newToken, "userid": targetCreds.id}
    else:
        return Response(status=400)

@app.route("/api/reservations", methods=["GET", "POST"])
def reservations():

    if request.method == "GET":
        return getReservations(request.args)

    elif request.method == "POST":
        data = request.form
        if data.get("book_id") == None:
            data = json.loads(request.data)

        if logInCheck(data["token"]) == False:
            return Response(status = 401)
        if int(token_to_user_id(data["token"])) != int(data["user_id"]):
            return Response(status = 401)
        
        requester = Users().query.filter_by(id = data['user_id']).first_or_404()
        newreservation = Reservation(user_id = data['user_id'], book_id = data['book_id']) # Reservation(user_id = data['user_id'], book_id = data['book_id'])
        db.session.add(newreservation)
        db.session.commit()
        db.session.refresh(newreservation)
        book = Book.query.filter_by(id = data['book_id']).first_or_404()
        owner = book.owner_rel
        if owner != None and owner.email != None and app.config["TESTING"] == False:
            send_simple_message(owner.email, "Book Requested - Library of Peers", f"Hi {owner.name}!\nAnother user, {requester.name}, has requested to borrow your copy of {book.title}.\nGet in touch with them at {requester.email}!\n\nLibrary of Peers")
        return model_to_dict(newreservation)

@app.route("/api/borrowed", methods=["GET", "POST", "DELETE"])
def borrowed():
    if request.method == "GET":
        borrowed = Borrowed.query

        # Search by user ID: /api/borrowed?user_id=xxx
        r_uid = request.args.get("user_id", default=False)
        if r_uid:
            borrowed = borrowed.filter_by(borrower = r_uid)

        # Search by book ID: /api/borrowed?book_id=xxx
        r_bid = request.args.get("book_id", default=False)
        if r_bid:
            borrowed = borrowed.filter_by(book_id = r_bid)

        # Search by owner of book: /api/borrowed?owner_id=xxx
        r_oid = request.args.get("owner_id", default=False)
        if r_oid:
            borrowed = borrowed.filter(Borrowed.book_rel.has(owner = r_oid))

        # Convert to list
        borrowed = borrowed.all()
        out = []
        for row in borrowed:
            toOut = model_to_dict(row)
            toOut['title'] = Book.query.filter_by(id = toOut['book_id']).first_or_404().title
            toOut['due'] = toOut['dateBorrowed'] + datetime.timedelta(days = 14)
            toOut['name'] = Users.query.filter_by(id = toOut['borrower']).first_or_404().name
            out.append(toOut)
        toReturn = {"borrowed": out}
        return toReturn

    elif request.method == "POST":

        data = request.form
        if data.get("book_id") == None:
            data = json.loads(request.data)

        # data = book_id (of book to request), user_id (of user borrowing book - NOT the logged in user!)

        if logInCheck(data["token"]) == False:
            return Response(status = 406)
        if int(token_to_user_id(data["token"])) != Book.query.filter_by(id = int(data["book_id"])).first_or_404().owner:
            return Response(status = 401)
        
        # Check if in reservations - if not, something has gone wrong!
        reservation = Reservation.query.filter_by(user_id = data['user_id'], book_id = data['book_id']).first_or_404()

        requester = Users().query.filter_by(id = data['user_id']).first_or_404()
        
        newborrow = Borrowed(borrower = data['user_id'], book_id = data['book_id'])

        db.session.add(newborrow)
        db.session.delete(reservation)
        db.session.commit()
        db.session.refresh(newborrow)
        book = Book.query.filter_by(id = data['book_id']).first_or_404()
        owner = book.owner_rel
        if owner != None and owner.email != None:
            send_simple_message(requester.email, "Book Available - Library of Peers", f"Hi {requester.name}!\n{owner.name} has accepted your request to borrow {book.title}.\nGet in touch with them at {owner.email} to arrange a time and place to pick it up!\nThis book will be due back at {newborrow.dateBorrowed + datetime.timedelta(days=14)}.\nLibrary of Peers")
        return model_to_dict(newborrow)
    
    elif request.method == "DELETE":
        # request args = book_id (of book to request), user_id (of user borrowing book - NOT the logged in user!), token

        book_id = request.args.get("book_id")
        token = request.args.get("token")

        if logInCheck(token) == False:
            return Response(status = 406)
        if int(token_to_user_id(token)) != Book.query.filter_by(id = int(book_id)).first_or_404().owner:
            return Response(status = 401)
        
        borrow = Borrowed.query.filter_by(book_id=book_id).first_or_404()
        db.session.delete(borrow)
        db.session.commit()
        return Response(status=204)


@app.route("/api/users/<int:id>/reservations", methods=["GET"])
def user_reservations(id):
    arguments = {"user_id": id}
    r_bid = request.args.get("book_id", default=False)
    if r_bid:
        arguments["book_id"] = r_bid
    return getReservations(arguments)

@app.route("/api/books/<int:id>/reservations", methods=["GET"])
def book_reservations(id):
    arguments = {"book_id": id}
    r_uid = request.args.get("user_id", default=False)
    if r_uid:
        arguments["user_id"] = r_uid
    return getReservations(arguments)
    
def getReservations(arguments):
    reservations = Reservation.query

    # Search by user ID: /api/reservations?user_id=xxx
    r_uid = arguments.get("user_id", False)
    if r_uid:
        reservations = reservations.filter_by(user_id = r_uid)

    # Search by book ID: /api/reservations?book_id=xxx
    r_bid = arguments.get("book_id", False)
    if r_bid:
        reservations = reservations.filter_by(book_id = r_bid)

    r_oid = arguments.get("owner_id", False)
    if r_oid:
        reservations = reservations.filter(Reservation.book_rel.has(owner = r_oid))

    # Convert to list
    reservations = reservations.all()
    out = []
    for row in reservations:
        toOut = model_to_dict(row)
        toOut['title'] = Book.query.filter_by(id = toOut['book_id']).first_or_404().title
        toOut['name'] = Users.query.filter_by(id = toOut['user_id']).first_or_404().name
        out.append(model_to_dict(row))
    toReturn = {"reservations": out}
    return toReturn

@app.route("/api/users/<int:id>/LenderRating", methods=["GET", "POST"]) 
def lenderRatings(id):
    if request.method == "GET":
        lRatings = LenderRatings.query
        l_uid = request.args.get("rated_userid", default=False)
                        
        totalScore=0
        noOfRatings=0
        if l_uid:
            lRatings = lRatings.filter_by(id = rated_userid)
            for entry in lRatings:
                totalScore = totalScore + entry.rating_value
                noOfRatings = noOfRatings+1
            
            lender_rating = totalScore/noOfRatings
        else:
            lender_rating=0
        
        return lender_rating
            
    elif request.method == "POST":
        data = request.form
        newRating = LenderRatings(rating_userid=int(token_to_user_id(data["token"])), rated_userid=id, rating_value=data['rating_value'])
        db.session.add(newRating)
        db.session.commit()
        db.session.refresh(newRating)
        return Response(status=200)

@app.route("/api/users/<int:id>/BorrowerRating", methods=["GET", "POST"]) 
def borrowerRatings(id):
    if request.method == "GET":
        bRatings = BorrowerRatings.query
        b_uid = request.args.get("rateduser_id", default=False)
                        
        totalScore=0
        noOfRatings=0
        if b_uid:
            bRatings = bRatings.filter_by(id = rateduser_id)
            for entry in bRatings:
                totalScore = totalScore + entry.rating_value
                noOfRatings = noOfRatings+1
            borrower_rating = totalScore/noOfRatings
        else:
            borrower_rating=0

        return borrower_rating
            
    elif request.method == "POST":
        data = request.form
        newRating = BorrowerRatings(rating_userid=int(token_to_user_id(data["token"])), rated_userid=id, rating_value=data['rating_value'])
        db.session.add(newRating)
        db.session.commit()
        db.session.refresh(newRating)
        return Response(status=200)
