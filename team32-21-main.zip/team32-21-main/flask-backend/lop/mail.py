import requests

def send_simple_message(target, subject, contents):
	return requests.post(
		"https://api.eu.mailgun.net/v3/libraryofpeers.barnett.work/messages",
		auth=("api", "9fd41d18b1d6ba93d2f5963a413a9772-53ce4923-40748ddf"),
		data={"from": "Library of Peers <system@libraryofpeers.barnett.work>",
			"to": [target],
			"subject": subject,
			"text": contents})

def send_html_message(target, subject, html_contents, text_contents="Sorry, this email was sent with HTML enabled."):
    return requests.post(
		"https://api.eu.mailgun.net/v3/libraryofpeers.barnett.work/messages",
		auth=("api", "9fd41d18b1d6ba93d2f5963a413a9772-53ce4923-40748ddf"),
		data={"from": "Library of Peers <system@libraryofpeers.barnett.work>",
			"to": [target],
			"subject": subject,
            "html": html_contents,
			"text": text_contents})