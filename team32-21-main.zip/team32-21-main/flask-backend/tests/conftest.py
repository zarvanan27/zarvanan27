import pytest
from urllib.parse import urlencode
import os

@pytest.fixture
def client():
    """Test client to run unit tests on Flask backend."""
    os.environ['POSTGRES_DB'] = "loptest"
    from lop import app

    app.app.config['TESTING'] = True
    app.db.drop_all()
    app.db.create_all()
    return app.app.test_client()

def full_call(client, path, params = {}):
    """Returns the Flask response object generated from visiting the given path."""
    url = path + "?" + urlencode(params)
    response = client.get(url)
    return response

def post_call(client, path, data = {}):
    response = client.post(path,data=data)
    return response

def put_call(client, path, data = {}):
    response = client.put(path, data=data)
    return response

def delete_call(client, path, data={}):
    response = client.delete(path, data=data)
    return response

def call(client, path, params = {}):
    """
    Returns the data retrieved from visiting the given path.
    May be HTML or JSON.
    """
    response = full_call(client, path, params)
    return response.data.decode()