from .conftest import call, delete_call, full_call, post_call, put_call
import json

def test_index_status_200(client):
    """
    Can the index page be accessed?
    """
    result = full_call(client, "/")
    assert(result.status == "200 OK")

def test_database_connection(client):
    """
    Can the database be accessed?
    """
    result = call(client, "/api/books")
    dict_result = json.loads(result)
    print(dict_result)
    assert(len(dict_result) == 1)

def test_book_creation(client):
    """
    If a book is created, can it be accessed after?
    """
    check = call(client, "/api/books")
    dict_result = json.loads(check)
    booksBefore = dict_result["books"]

    someUser = json.loads(post_call(client, "/api/users/create", {"name": "John Smith", "email": "johnmith@mail.com", "password": "qwerty"}).data.decode())
    post_call(client, "/api/books", {"title": "The Bible", "token": someUser['token']}).data.decode()

    check2 = call(client, "/api/books")
    dict_result2 = json.loads(check2)
    booksAfter = dict_result2["books"]
    
    assert len(booksAfter) == len(booksBefore) + 1

def test_user_creation(client):
    """
    If a user is created, can it be accessed after?
    """
    check = call(client, "/api/users")
    dict_result = json.loads(check)
    usersBefore = dict_result["users"]

    post_call(client, "/api/users/create", {"name": "John Smith", "email": "johnmith@mail.com", "password": "qwerty"}).data.decode()

    check2 = call(client, "/api/users")
    dict_result2 = json.loads(check2)
    usersAfter = dict_result2["users"]
    
    assert len(usersAfter) == len(usersBefore) + 1

def test_login(client):
    """
    Tests logging in with correct credentials
    """
    post_call(client, "/api/users/create", {"email": "testuser1@mail.com", "password": "qwerty", "name": "John Smith"})
    returned = post_call(client, "/api/users/login", {"email": "testuser1@mail.com", "password": "qwerty"})
    
    check = returned.data.decode()
    dict_result = json.loads(check)
    token = dict_result["token"]
    
    assert returned.status == '200 OK' and token != ""

def test_login_bad_email(client):
    """
    Tests attempting to log in with an incorrect email
    """

    returnedStatus = post_call(client, "/api/users/login", {"email": "notarealuser@mail.com", "password": "qwerty"}).status
    
    assert returnedStatus == '404 NOT FOUND'

def test_login_bad_password(client):
    """
    Tests attempting to log in with a correct email and incorrect password
    """

    post_call(client, "/api/users/create", {"email": "testuser2@mail.com", "password": "qwerty", "name": "John Smith"})
    returnedStatus = post_call(client, "/api/users/login", {"email": "testuser2@mail.com", "password": "password"}).status
    
    assert returnedStatus == '400 BAD REQUEST'#I *think* this is the right code.

def test_user_id(client):
    
    """
    Tests creating a user then accessing their information.
    """
    response = post_call(client, "/api/users/create", {"email": "johnsmith@mail.com", "password": "qerty", "name": "John Smith"}).data.decode()
    result = call(client, "/api/users/"+str(json.loads(response)["userid"]))
    dict_result = json.loads(result)
    name = dict_result["name"]
    
    assert name == "John Smith"

def test_create_reservation(client):
    """
    Create a reservation as a logged in user.
    """
    someUser = post_call(client, "/api/users/create", {"name": "Bob Jobson", "email": "crob@mail.com", "password": "bob"}).data.decode()
    someBook = post_call(client, "/api/books", {"title": "The Bible 2", "token": json.loads(someUser)['token']}).data.decode()

    someBookID = json.loads(someBook)['id']
    someUserID = json.loads(someUser)['userid']

    loggedIn = post_call(client, "/api/users/login", {"email": "crob@mail.com", "password": "bob"}).data.decode()
    userToken = json.loads(loggedIn)['token']

    response = post_call(client, "/api/reservations", {"token": userToken, "user_id": someUserID, "book_id": someBookID})
    result = call(client, "/api/reservations", {"user_id": someUserID, "book_id": someBookID})
    dict_result = json.loads(result)
    name = dict_result["reservations"]
    
    assert len(name) == 1
    
def test_no_users(client):
    """
    Before users are added, is the user table empty?
    """
    result = call(client, "/api/users")
    dict_result = json.loads(result)
    users = dict_result["users"]
    
    assert len(users) == 0

def test_book_put(client):
    """
    Tests editing book information
    """
    someUser = post_call(client, "/api/users/create", {"name": "Bob Jobson", "email": "crob@mail.com", "password": "bob"}).data.decode()
    someUser = json.loads(someUser)

    initial = post_call(client, "/api/books", {"title": "The Bible", "description": "A holy text", "image": "image1", "token": someUser['token']}).data.decode()
    thebook = json.loads(initial)
    assert thebook['title'] == "The Bible"
    assert thebook['description'] == "A holy text"
    changedCall = put_call(client, f"/api/books/{thebook['id']}", {"title": "The New Testament", "description": "Part of a holy text", "image": "image2", "token": someUser['token']})
    changed = changedCall.data.decode()
    thebook2 = json.loads(changed)
    assert thebook2['title'] == "The New Testament"
    assert thebook2['description'] == "Part of a holy text"
    assert thebook2['id'] == thebook['id']

def test_book_delete(client):
    """
    Tests editing book information
    """
    someUser = post_call(client, "/api/users/create", {"name": "Bob Jobson", "email": "crob@mail.com", "password": "bob"}).data.decode()
    someUser = json.loads(someUser)

    initial = post_call(client, "/api/books", {"title": "The Bible", "description": "A holy text", "image": "image1", "token": someUser['token']}).data.decode()
    idnumber = json.loads(initial)['id']
    response = delete_call(client, f"/api/books/{idnumber}", {"token": someUser['token']})
    assert response.status == "204 NO CONTENT"

    response2 = full_call(client, f"/api/books/{idnumber}")
    assert response2.status == "404 NOT FOUND"
def test_isbn_api(client):
    """
    Can ISBN data be retrieved?
    """
    result = call(client, "/api/books/isbn/9780613496742")
    dict_result = json.loads(result)
    
    assert dict_result['author'] == "J. K. Rowling"
    assert dict_result['title'] == "Harry Potter and the Goblet of Fire"
    assert len(dict_result['image']) > 5

def test_isbn_api_fail(client):
    """
    Does the ISBN API fail with the correct error codes?
    """
    result = full_call(client, "/api/books/isbn/bees")

    assert result.status == "404 NOT FOUND"
